module.exports = {
  testTimeout: 20000,
};
